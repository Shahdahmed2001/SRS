-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for driveo
CREATE DATABASE IF NOT EXISTS `driveo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `driveo`;

-- Dumping structure for table driveo.cars_table
CREATE TABLE IF NOT EXISTS `cars_table` (
  `car_name` varchar(255) NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table driveo.cars_table: ~7 rows (approximately)
INSERT INTO `cars_table` (`car_name`, `id`, `description`, `status`, `price`, `photo`, `link`, `user_name`) VALUES
	('Audi', 2, 'Luxury, performance, innovative design.', 'Available', 900000.00, '../cars/uploads/audy.jpg', 'https://www.tesla.com', 'Shahd Mahmoud'),
	('BMW', 3, 'Dynamic, premium, ultimate driving experience.', 'Available', 500000.00, '../cars/uploads/pngtree-bmw-car-body-and-close-up-photo-image_15534217.png', 'https://www.tesla.com', 'Omar Akram'),
	('SUBARU', 4, 'Reliable, adventurous, all-wheel drive.', 'Available', 150000.00, '../cars/uploads/forester-il-my23-nav2.jpg', 'https://www.tesla.com', 'Abdullah Ahmed'),
	('HONDA', 5, 'Efficient, reliable, innovative performance.', 'Available', 600000.00, '../cars/uploads/maxresdefault.jpg', 'https://www.tesla.com', 'Mohamed Saber '),
	('15pbmw2023', 8, 'dosra levy ,white color ,petrol fuel type ,125 mileage ,sedan category, yes leather ,20liter engine volume ,12 cylinbders ,automatic gear box,4x4 wheel ,4 doors ,2 airbags .', 'new', 1200000.00, '../cars/uploads/car_6751dd45231696.76043595.jpeg', '0', 'shahd ahmed masoud'),
	('chevrolet20cc2022', 10, 'gasolina levy ,blue color ,petrol fuel type ,125 mileage ,jeep category, yes leather ,20liter engine volume ,52 cylinbders ,automatic gear box,4x4 wheel ,4 doors ,4 airbags .', 'new', 126000.00, '../cars/uploads/car_675738828f1b99.60193388.jpeg', '0', 'omar takey'),
	('ford 500cc 2021', 20, '200 levy ,grey color ,petrol fuel type ,125 mileage ,jeep category, yes leather ,2.1 engine volume ,2 cylinders ,automatic gear box,left wheel ,4 doors ,4 airbags 4x4 drive wheels .', 'new', 2846665.00, '../cars/uploads/car_6765a9b4917f97.71492166.jpeg', '0', 'omar takey');

-- Dumping structure for table driveo.user
CREATE TABLE IF NOT EXISTS `user` (
  `Email` text NOT NULL,
  `user_name` text NOT NULL,
  `phone` varchar(50) NOT NULL DEFAULT '0',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0',
  `user_id` smallint NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `password` (`password`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table driveo.user: ~10 rows (approximately)
INSERT INTO `user` (`Email`, `user_name`, `phone`, `password`, `user_id`) VALUES
	('d.shahdahmed020@gmail.com', 'Shahd Ibrahim', '+201006792319', '$2y$10$ci66qNCheVOckA21azZTLeIzN2BSGhX1JSk1sIUUaqXcDAQgP61Yi', 8),
	('ShahdMahmoud2003@gmail.com', 'Shahd Mahmoud', '+201129759412', '$2y$10$3NgB8J.2Q/uVH7m2oZrjhu0Vw6IA3HHJjf3uCwNCGypRuh4aP9/z6', 9),
	('Abdullah2003@gmail.com', 'Abdullah Ahmed', '+201096198496', '$2y$10$R2c9nZwkWw/WaaVWIl3YAeLqwK0.NcoIHAyLd3zA5aBiwPVEuvUQu', 10),
	('OmarAkram@gmail.com', 'Omar Akram', '+201149092186', '$2y$10$pshr1DT.dK46/o6m4WRe/O2pFY.ijL6oJdgPKHzjvv2/OyFr2MxMW', 11),
	('MS2003@gmail.com', 'Mohamed Saber ', '+201280890083', '$2y$10$jrGEi0/yAt1X27uIinj0u.s9l6UmfV2zOh0EQsdtxYuNqcejwHyKq', 12),
	('Shahd-Ahmed18@h-eng.helwan.edu.eg', 'shahd ahmed masoud', '+20100126548', '$2y$10$76dlVp0k1CMMCoaoR0YWZ.kQkCegoC9E8TXa5pLg6DNM0DyIG0HfS', 13),
	('ahmedaly980@gmail.com', 'Ahmed ibrahim', '+201001041971', '$2y$10$pixHBvrHZjLTyWmTpSJi9.A0Mew5b3g1RCrB7crUzYwHsodvcsqGa', 15),
	('marwa1974@gmail.com', 'marwa ahmed', '+20 115 422 6681', '$2y$10$6XShIjebiU/G2wZKA9y9F.0o5hn5BATmyUSogChwvw5tuMxmVH7/q', 16),
	('mariam2009@gmail.com', 'mariam ahmed', '+201067238370', '$2y$10$CW6qUC6ZCAT/RVNQpHYW9.bMpNquBPgMgjzC1RTE1MR8v4o6p.CN6', 17),
	('omar1996@gmail.com', 'omar takey', '+201097295558', '$2y$10$2MjjrZABs6.eneeeSgRsHOkhFnUfvuuzeUI.FxmB2VaUd7fUDscOW', 18);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
