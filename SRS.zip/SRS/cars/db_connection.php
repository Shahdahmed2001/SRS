﻿<?php
$servername = "localhost"; // اسم الخادم (افتراضي في Laragon هو localhost)
$username = "root";       // اسم المستخدم (افتراضي في Laragon هو root)
$password = "";           // كلمة المرور (فارغة افتراضيًا في Laragon)
$dbname = "driveo"; // اسم قاعدة البيانات التي أنشأتها

// إنشاء اتصال بقاعدة البيانات
$conn = new mysqli($servername, $username, $password, $dbname);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
