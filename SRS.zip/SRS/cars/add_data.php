﻿<?php
// استدعاء ملف الاتصال
include 'db_connection.php';

// بيانات الجدول التي سيتم إدخالها
$car_name = "HONDA";
$description = "Efficient, reliable, innovative performance.";
$status = "Available";
$price = "600000";
$photo = "assets/images/maxresdefault (1).jpg";
$link = "https://www.tesla.com";
$user_name = "Mohamed Saber "; // أدخل هنا اسم المستخدم

// استعلام الإدخال
$sql = "INSERT INTO cars_table (car_name, description, status, price, photo, link, user_name) 
        VALUES ('$car_name', '$description', '$status', '$price', '$photo', '$link', '$user_name')";

// تنفيذ الاستعلام
if ($conn->query($sql) === TRUE) {
    echo "تمت إضافة البيانات بنجاح!";
} else {
    echo "خطأ: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
