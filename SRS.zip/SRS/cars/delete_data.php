﻿<?php
// استدعاء ملف الاتصال
include 'db_connection.php';

// استعلام لحذف جميع البيانات في الجدول
$sql = "DELETE FROM cars_table";

if ($conn->query($sql) === TRUE) {
    echo "تم حذف جميع البيانات بنجاح!";
} else {
    echo "خطأ في الحذف: " . $conn->error;
}

$conn->close();
?>
