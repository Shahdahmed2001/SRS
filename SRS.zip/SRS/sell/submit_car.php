<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli('localhost', 'root', '', 'driveo');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Log incoming POST data to debug
error_log(print_r($_POST, true));

// Retrieve POST data (car details)
$data = [
    'car_name' => $_POST['car_name'] ?? '',
    'description' => $_POST['description'] ?? '',
    'status' => $_POST['status'] ?? '',
    'price' => $_POST['price'] ?? '',
    'photo' => $_POST['photo'] ?? '',
    'user_name' => $_POST['user_name'] ?? ''
];

// Validate incoming data (check for empty fields)
if (empty($data['car_name']) || empty($data['description']) || empty($data['status']) ||
    empty($data['price']) || empty($data['photo']) || empty($data['user_name'])) {
    echo json_encode(['success' => false, 'message' => 'Incomplete data received.']);
    exit;
}

// Check if car with the same name and user already exists
$stmt = $conn->prepare("SELECT * FROM cars_table WHERE car_name = ? AND user_name = ?");
$stmt->bind_param("ss", $data['car_name'], $data['user_name']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Car already exists.']);
    exit;
}

// Handle the image upload
$imagePath = null;
if (!empty($data['photo'])) {
    $base64Photo = $data['photo'];

    // Check if the base64 string contains the proper prefix
    if (strpos($base64Photo, 'data:image/') === 0) {
        // Extract the image type (e.g., 'jpeg', 'png', etc.)
        preg_match('/data:image\/(\w+);base64,/', $base64Photo, $matches);
        $imageType = $matches[1];

        // Remove the base64 data URL prefix
        $imageData = substr($base64Photo, strpos($base64Photo, ',') + 1);

        // Decode the base64 image data
        $imageContent = base64_decode($imageData);
        if ($imageContent === false) {
            echo json_encode(["success" => false, "message" => "Invalid base64 image data."]);
            exit;
        }

        // Save the image to the server
        $imageName = uniqid("car_", true) . "." . $imageType;  // Generate unique file name
        $imagePath = "../cars/uploads/" . $imageName;

        // Create the uploads directory if it doesn't exist
        if (!file_exists("../cars/uploads")) {
            if (!mkdir("../cars/uploads", 0777, true)) {
                die(json_encode(["success" => false, "message" => "Failed to create uploads directory."]));
            }
        }

        // Write the image content to a file
        if (!file_put_contents($imagePath, $imageContent)) {
            echo json_encode(["success" => false, "message" => "Failed to save the image file."]);
            exit;
        }
    } else {
        echo json_encode(["success" => false, "message" => "Malformed base64 image data."]);
        exit;
    }
}

// Insert car data into the database
$stmt = $conn->prepare("INSERT INTO cars_table (car_name, description, status, price, photo, link, user_name) 
                        VALUES (?, ?, ?, ?, ?, '0', ?)");
$stmt->bind_param("ssssss", $data['car_name'], $data['description'], $data['status'], $data['price'], $imagePath, $data['user_name']);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Car details successfully saved.']);
} else {
    error_log("MySQL Error: " . $stmt->error);
    echo json_encode(['success' => false, 'message' => 'Failed to insert car details.']);
}

$stmt->close();
$conn->close();
?>
