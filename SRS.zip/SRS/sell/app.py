from flask import Flask, request, jsonify
import joblib
import pandas as pd
from flask_cors import CORS  

app = Flask(__name__)
CORS(app)

# Load the model and preprocessor
try:
    model = joblib.load('C:\\laragon\\www\\SRS\\sell\\xgb_model.pkl')
    processor = joblib.load('C:\\laragon\\www\\SRS\\sell\\data_transformer_preprocessing.pkl')
except FileNotFoundError as e:
    print(f"Error loading files: {e}")
    model = None
    processor = None

columns_data = [
    'levy', 'brand', 'category', 'leather', 'fuelType',
    'engineVol', 'mileage', 'cylinders', 'type', 'driveWheels',
    'doors', 'wheel', 'color', 'airbags', 'age'
]

@app.route('/predict', methods=['POST'])
def predict():
    if not model or not processor:
        return jsonify({'error': 'Model or preprocessor not loaded.'}), 500

    try:
        # Check if the request contains JSON data
        if not request.is_json:
            return jsonify({'error': 'Request must be in JSON format.'}), 400

        # Parse the JSON data
        data = request.get_json()

        # Log the received data
        print(f"Received data: {data}")

        # Ensure the 'features' key exists in the received data
        if not data or 'features' not in data[0]:  # Check the first item in the list for 'features'
            return jsonify({'error': 'Invalid input. Missing "features" key.'}), 400

        # Extract the features from the first item in the list
        features = data[0]['features']  # Extract the 'features' list of dictionaries
        if not isinstance(features, list) or len(features) == 0:
            return jsonify({'error': 'Features must be a non-empty list of feature dictionaries.'}), 400

        # Create DataFrame from the features list (it's already a list of dictionaries)
        data_without_processing = pd.DataFrame(features)

        # Print the DataFrame for debugging
        data_without_processing.columns= ['levy', 'brand', 'category', 'leather_interior', 'fuel_type','engine_volume', 'mileage', 'cylinders', 'type', 'drive_wheels','doors', 'wheel', 'color', 'airbags', 'car_age']
        print(f"DataFrame before processing:\n{data_without_processing}")
       
        # Check for missing or invalid values
        if data_without_processing.isnull().any().any():
            return jsonify({'error': 'Some fields have invalid or missing values.'}), 400

        # Convert numeric columns to float
        numeric_columns = ['levy']
        for col in numeric_columns:
            data_without_processing[col] = pd.to_numeric(data_without_processing[col], errors='coerce')

        # Check for missing or invalid values
        if data_without_processing.isnull().any().any():
            return jsonify({'error': 'Some numeric fields have invalid or missing values after conversion.'}), 400

        # Apply preprocessing
        data_with_processing = processor.transform(data_without_processing)

        # Predict and scale the result
        y_pred = model.predict(data_with_processing)
        final_result = (y_pred * (5.443288e+06 - 1.000000e+02)) + 1.000000e+02

        return jsonify({'prediction': float(final_result[0])})
    except Exception as e:
        # Log the error for debugging
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)