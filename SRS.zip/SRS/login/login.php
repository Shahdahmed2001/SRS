<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli('localhost', 'root', '', 'driveo');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the request
$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

// Validate input data
if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
    exit();
}

// Prepare and execute the query to find the user by email
$stmt = $conn->prepare("SELECT * FROM user WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Compare the entered password with the hashed password in the database
    if (password_verify($password, $user['password'])) {
        // Successfully authenticated, return user info including the username
        echo json_encode([
            'success' => true,
            'message' => 'Login successful.',
            'username' => $user['user_name']  
        ]);
    } else {
        // Incorrect password
        echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
    }
} else {
    // No user found with the entered email
    echo json_encode(['success' => false, 'message' => 'User not found.']);
}

$stmt->close();
$conn->close();
?>
