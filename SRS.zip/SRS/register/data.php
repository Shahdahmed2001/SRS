<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli('localhost', 'root', '', 'driveo');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = [
    'fullName' => $_POST['fullName'] ?? '',
    'email' => $_POST['email'] ?? '',
    'phone' => $_POST['phone'] ?? '',
    'password' => password_hash($_POST['password'] ?? '', PASSWORD_BCRYPT),
];

// Check for duplicates
$stmt = $conn->prepare("SELECT * FROM user WHERE email = ? OR phone = ?");
$stmt->bind_param("ss", $data['email'], $data['phone']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo 'Email or phone number already in use.';
} else {
    $stmt = $conn->prepare("INSERT INTO user (user_name, Email, phone, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $data['fullName'], $data['email'], $data['phone'], $data['password']);

    if ($stmt->execute()) {
        echo 'Account created successfully!';
    } else {
        echo 'Failed to create account.'. $stmt->error;;
    }
}

$stmt->close();
$conn->close();
?>
