﻿
<?php
// استدعاء ملف الاتصال بقاعدة البيانات
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db_connection.php';

// التحقق من وجود 'id' في URL والتأكد أنه رقم
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $car_id = $_GET['id'];
    
    // استعلام للحصول على بيانات السيارة بناءً على id باستخدام الاستعلام المحضر
    $sql = "SELECT cars_table.*, user.phone 
            FROM cars_table 
            JOIN user ON cars_table.user_name = user.user_name 
            WHERE cars_table.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id); // ربط المعامل مع القيمة (i تعني أن القيمة عدد صحيح)
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
         $car = $result->fetch_assoc();
        $phone_number = $car['phone'];
    } else {
        echo "Car not found!";
        exit;
    }
} else {
    echo "No valid ID provided!";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Car Details - <?php echo $car['car_name']; ?></title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@400;600;700&display=swap" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" />
    <link rel="stylesheet" href="index.css" />
    <style>
 
      .car-image {
        width: 100%; /* عرض الصورة 100% من حجم العنصر الحاوي */
        height: 450px; /* الحفاظ على نسب الصورة */
        max-width: 1000px; /* تحديد الحجم الأقصى للصورة */
        display: block;
        margin: 0 auto;}

   button {
    background-color: #25D366; /* لون واتساب */
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    color: white;
    font-size: 16px;
    cursor: pointer;
    text-align: center;
          }

button a {
    text-decoration: none;
    color: white;
         }

button:hover {
    background-color: #1DA851; /* لون أغمق عند التمرير */
}

      
    </style>
  </head>
  <body>
  <div class="rectangle-e">
      <div class="image-f"></div>
      <a href="../Home/home.html" class="home">Home</a>
      <a href="../activity/activity.html" class="activity">Activity</a>
      <a href="../contact_us/index.html" class="contact">Contact</a>
      <a href="../about_us/index.html" class="about-us">About Us</a>
      <a href="../sell/index.html" class="sell">Sell</a>
      <span class="shahd-ahmed" id="usernameDisplay">Shahd Ahmed 2001</span>
    </div>
    <div class="main-container">
      <div class="frame">
        <!-- Car Details Section -->
        <div class="carousel">
          <div class="frame-2">
          </div>
          <div class="image-8">
          <img src="<?php echo $car['photo']; ?>" alt="Car Image" class="car-image" />
          </div>
        </div>
        
        <div class="flex-row-ec">
          <div class="frame-9">
            <span class="description">Description</span>
            <span class="description-a"><?php echo nl2br($car['description']); ?></span>
           
          </div>
          <button class="button-primary-outline">
            <span class="button">$<?php echo number_format($car['price'], 2); ?></span>
          </button>
        </div>

       
   <button class="button-button-primary">
  <span class="contact-dealer">  
      <a href="https://wa.me/<?php echo $phone_number; ?>" target="_blank">
          Contact Dealer
      </a>
  </span>
</button>
        
        <!-- Location Section -->
        <div class="frame-13">
          <span class="location">Location</span>
          <span class="e-tsala-apopka-dr">9500 E Tsala Apopka Dr, Floral City, FL, 34436, Florida, USA</span>
          <div class="frame-14">
            <div class="rectangle-15"></div>
          </div>
        </div>
      </div>

      <div class="rectangle-16">
        <div class="rectangle-17">

          <div class="rectangle-1a">
            <span class="tesla-model-standard-range-plus"><?php echo nl2br($car['car_name']); ?></span>
            <span class="homepage-new-car-list-car-detail">Homepage - New Car List - Car Detail</span>
          </div>
        </div>
      </div>
    </div>
  </body>
  <script>
      // Retrieve the username from localStorage
      const username = localStorage.getItem('username');

// Display the username if it exists
if (username) {
    document.getElementById('usernameDisplay').textContent = ` ${username}`;
}
</script>
</html>