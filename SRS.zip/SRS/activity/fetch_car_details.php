<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default Laragon username
$password = ""; // Default Laragon password
$dbname = "driveo";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id']; 

// Query to fetch car details by ID
$sql = "SELECT price, photo, description, car_name FROM `cars_table` WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if a result was returned
if ($row = $result->fetch_assoc()) {
    // Return a single car object
    echo json_encode($row);
} else {
    // If no car was found, return an error message
    echo json_encode(['error' => 'Car not found']);
}

$stmt->close();
$conn->close();
?>
