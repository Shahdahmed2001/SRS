<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "driveo";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id']; // Get car ID to delete

$sql = "DELETE FROM `cars_table` WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Car deleted successfully.";
} else {
    echo "Error deleting car: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
