<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Log incoming data (optional, for debugging purposes)
file_put_contents('log.txt', print_r(file_get_contents('php://input'), true));

$data = json_decode(file_get_contents('php://input'), true);

// Check if all required fields are present
if (isset($data['id'], $data['car_name'], $data['description'], $data['price'], $data['photo'])) {
    $carId = $data['id'];
    $carName = $data['car_name'];
    $description = $data['description'];
    $price = $data['price'];
    $photo = $data['photo'];

    // Handle the base64 image
    $imagePath = null;

    // Check if photo is provided
    if (!empty($photo)) {
        // Extract the image type (e.g., jpg, png)
        if (preg_match('/^data:image\/(\w+);base64,/', $photo, $matches)) {
            $imageType = $matches[1];  // e.g., 'jpeg', 'png'
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($imageType, $allowedTypes)) {
                echo json_encode(['success' => false, 'message' => 'Invalid image type.']);
                exit;
            }

            // Extract the base64 image data
            $imageData = substr($photo, strpos($photo, ',') + 1);
            $imageContent = base64_decode($imageData);
            if ($imageContent === false) {
                echo json_encode(['success' => false, 'message' => 'Invalid image data.']);
                exit;
            }

            // Generate a unique image name and define the upload directory
            $imageName = uniqid('car_', true) . '.' . $imageType;
            $imagePath = '../cars/uploads/' . $imageName;

            // Check if the image already exists in the folder
            if (file_exists($imagePath)) {
                // If the image already exists, reuse the existing image
                echo json_encode(['success' => true, 'message' => 'Image already exists, reusing existing image.']);
            } else {
                // Ensure the directory exists
                if (!file_exists('../cars/uploads')) {
                    if (!mkdir('../cars/uploads', 0755, true)) {
                        echo json_encode(['success' => false, 'message' => 'Failed to create photos directory.']);
                        exit;
                    }
                }

                // Save the image to the server if it does not exist
                if (file_put_contents($imagePath, $imageContent) === false) {
                    echo json_encode(['success' => false, 'message' => 'Failed to save the image.']);
                    exit;
                }
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid image format.']);
            exit;
        }
    }

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'driveo');

    // Check database connection
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
        exit;
    }

    // Update the car record in the database, including the image path
    $query = "UPDATE cars_table SET car_name=?, description=?, price=?, photo=? WHERE id=?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        // Bind parameters to the query
        $stmt->bind_param("ssdsi", $carName, $description, $price, $imagePath, $carId);
        
        // Execute the query and return the response
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Car details updated successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error updating car: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Error preparing the query.']);
    }

    // Close the database connection
    $conn->close();

} else {
    // Handle missing required fields
    echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
}
?>
