<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default Laragon username
$password = ""; // Default Laragon password
$dbname = "driveo";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$user_name = $_GET['user_name']; 

// Query to fetch cars for the user
$sql = "SELECT id,price,photo,description, car_name FROM `cars_table` WHERE user_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_name);
$stmt->execute();
$result = $stmt->get_result();

// Prepare data
$cars = [];
while ($row = $result->fetch_assoc()) {
    $cars[] = $row;
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($cars);

$stmt->close();
$conn->close();
?>
